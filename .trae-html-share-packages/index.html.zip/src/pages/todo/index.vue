<template>
  <div class="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto">
    <div class="flex items-center justify-between flex-wrap gap-3 mb-5">
      <div>
        <h2 class="text-lg font-semibold text-gray-900">我的代办</h2>
        <p class="mt-0.5 text-sm text-gray-500">跟踪需要处理的消息</p>
      </div>
      <AppButton variant="secondary" size="sm" :loading="loading" @click="refresh">
        <AppIcon name="refresh" class="h-4 w-4" />
        刷新
      </AppButton>
    </div>

    <div class="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
      <!-- Segmented tabs -->
      <div class="flex p-1 rounded-lg bg-gray-100 w-fit">
        <button
          v-for="tab in tabs"
          :key="tab.status"
          type="button"
          class="px-4 py-1.5 text-sm rounded-md transition-colors whitespace-nowrap"
          :class="
            activeTab === tab.status
              ? 'bg-white text-gray-900 shadow-sm font-medium'
              : 'text-gray-500 hover:text-gray-700'
          "
          @click="switchTab(tab.status)"
        >
          {{ tab.label }}
        </button>
      </div>

      <!-- Title search -->
      <div class="relative sm:ml-auto w-full sm:w-64">
        <AppIcon
          name="search"
          class="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400"
        />
        <input
          v-model="messageTitle"
          type="text"
          placeholder="按标题搜索，回车查询"
          class="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-gray-300 bg-white outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/25"
          @keyup.enter="search"
        />
      </div>
    </div>

    <AppCard :padding="false">
      <!-- Loading skeleton -->
      <div v-if="loading && rows.length === 0" class="divide-y divide-gray-100">
        <div v-for="i in 5" :key="i" class="p-4 sm:p-5 animate-pulse space-y-2">
          <div class="h-3.5 bg-gray-200 rounded w-1/4"></div>
          <div class="h-3 bg-gray-100 rounded w-3/4"></div>
          <div class="h-3 bg-gray-100 rounded w-1/2"></div>
        </div>
      </div>

      <!-- Message list -->
      <ul v-else-if="rows.length > 0" class="divide-y divide-gray-100">
        <li
          v-for="row in rows"
          :key="row.id"
          class="px-4 sm:px-5 py-3.5 hover:bg-gray-50 transition-colors flex gap-3"
        >
          <span
            class="mt-1.5 h-2 w-2 rounded-full shrink-0"
            :class="row.messageStatus === 1 ? 'bg-primary' : 'bg-gray-200'"
          ></span>
          <div class="flex-1 min-w-0">
            <div class="flex items-baseline justify-between gap-2">
              <p class="text-sm font-medium text-gray-900 truncate">{{ row.fromUserName }}</p>
              <span class="shrink-0 text-xs text-gray-400">{{ row.createTime }}</span>
            </div>
            <p class="mt-0.5 text-sm text-gray-700 truncate">{{ row.messageTitle }}</p>
            <p class="mt-0.5 text-xs text-gray-500 line-clamp-2">{{ row.messageContent }}</p>
          </div>
        </li>
      </ul>

      <AppEmpty v-else-if="!loading" text="暂无代办消息" />
    </AppCard>

    <AppPagination
      v-if="total > 0"
      :page="pageNum"
      :total="total"
      :page-size="pageSize"
      :loading="loading"
      @change="changePage"
    />

    <p v-if="errorMsg" class="mt-4 text-sm text-red-600">{{ errorMsg }}</p>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { listTodoApp } from "@/api";
import type { TodoMessage } from "@/api";
import AppIcon from "@/components/ui/AppIcon.vue";
import AppButton from "@/components/ui/AppButton.vue";
import AppCard from "@/components/ui/AppCard.vue";
import AppEmpty from "@/components/ui/AppEmpty.vue";
import AppPagination from "@/components/ui/AppPagination.vue";

const pageSize = 10;
const pageNum = ref(1);
const total = ref(0);
const rows = ref<TodoMessage[]>([]);
const loading = ref(false);
const errorMsg = ref("");

// Filter values match the record field enum: 1 = todo, 2 = done
const tabs = [
  { label: "待办", status: 1 },
  { label: "已办", status: 2 },
] as const;

const activeTab = ref<number>(1);
const messageTitle = ref("");

const totalPages = computed(() => Math.max(1, Math.ceil(total.value / pageSize)));

async function fetchList() {
  loading.value = true;
  errorMsg.value = "";
  try {
    const body = (
      await listTodoApp({
        pageSize,
        pageNum: pageNum.value,
        platform: 1,
        messageStatus: activeTab.value,
        messageTitle: messageTitle.value || undefined,
      })
    ).data;
    if (body.code !== 200) throw new Error(body.msg || `请求失败（${body.code}）`);
    rows.value = body.rows;
    total.value = body.total;
  } catch (e) {
    errorMsg.value = e instanceof Error ? e.message : String(e);
  } finally {
    loading.value = false;
  }
}

function switchTab(status: number) {
  if (activeTab.value === status) return;
  activeTab.value = status;
  pageNum.value = 1;
  fetchList();
}

function search() {
  pageNum.value = 1;
  fetchList();
}

function changePage(p: number) {
  if (p < 1 || p > totalPages.value || p === pageNum.value) return;
  pageNum.value = p;
  fetchList();
}

function refresh() {
  fetchList();
}

onMounted(fetchList);
</script>