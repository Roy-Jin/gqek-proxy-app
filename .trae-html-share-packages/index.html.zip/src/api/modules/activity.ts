import { http } from "../client.js";
import type { RequestOptions } from "../../utils/request.js";

/** My activity list query params */
export interface MyActivityParams {
  /** Page size */
  pageSize: number;
  /** Page number */
  pageNum: number;
  /** Activity type */
  type: number;
  [key: string]: unknown;
}

/** Activity entry from myActivitiyInfoByStudent */
export interface ActivityInfo {
  activityId: string;
  activityName: string;
  activityAvatarUrl: string | null;
  /** Organizer name */
  maintainerName: string;
  teacherName: string | null;
  activityClassifyName: string;
  activityLocation: string;
  /** Activity duration in hours, e.g. "0.5" */
  attendTime: string;
  memberNum: number;
  status: number;
  activityStartTime: string;
  activityEndTime: string;
  registerStartTime: string;
  registerEndTime: string;
  createTime: string;
  [key: string]: unknown;
}

/** Paged response of myActivitiyInfoByStudent (flat, uses rows) */
export interface MyActivityResult {
  code: number;
  msg: string;
  total: number;
  rows: ActivityInfo[];
  [key: string]: unknown;
}

/**
 * Get my activity list by student
 * GET /activity/activityInfo/myActivitiyInfoByStudent
 */
export function listMyActivityByStudent(
  params: MyActivityParams,
  opts?: RequestOptions
) {
  return http.get<MyActivityResult>(
    "/activity/activityInfo/myActivitiyInfoByStudent",
    params,
    opts
  );
}
